import {Component, OnInit} from '@angular/core';
import {TepMenuItem} from '../../../../_models/tepmenu';
import {GeneralSettings, HouseInfo} from '../../../../_models/common';
import {Observable} from 'rxjs';
import {DefectList, DefectlistEntry, DefectListEntryDetail, DefectRef} from '../../../../_models/defectlist';
import {CommonService} from '../../../../_services/common.service';
import {ActivatedRoute, Router} from '@angular/router';
import {SettingsService} from '../../../../_services/settings.service';
import {TechstateService} from '../../../../_services/techstate.service';
import {first} from 'rxjs/operators';
import {FormArray, FormBuilder, FormControl, FormGroup, Validators} from '@angular/forms';
import {Statuses} from '../../../../_models/filters';
import {DocumentsService} from '../../../../_services/documents.service';

@Component({
  selector: 'app-techstateedit',
  templateUrl: './techstateedit.component.html',
  styleUrls: ['./techstateedit.component.scss']
})
export class TechstateeditComponent implements OnInit {

  tepMenu: TepMenuItem[];
  statuses: Statuses[] = [];
  house_id: number;
  defect_id: number;
  defect_entry_id: number;
  tep_part: string;
  menuTitle: string;
  max_number: number;

  house_info: HouseInfo;

  settings$: Observable<GeneralSettings>;

  defect: DefectList;
  current_defect: DefectlistEntry[];
  defectentry: DefectlistEntry;
  defectref$: Observable<DefectRef>;
  newForm: FormGroup;

  imageObject: Array<object> = [];

  get f() { return this.newForm.controls; }

  constructor(
    private common: CommonService,
    private route: ActivatedRoute,
    private router: Router,
    private settings: SettingsService,
    private api: TechstateService,
    private apiFiles: DocumentsService,
    private formBuilder: FormBuilder
  ) { }

  ngOnInit() {
    this.tepMenu = this.route.snapshot.data['tepMenu'];

    this.settings$ = this.settings.settings$;



    this.route.url.subscribe(url => {

      this.house_id = parseFloat(url[1].path);
      this.tep_part = url[2].path;
      this.defect_id = parseInt(url[3].path, 10);
      this.defect_entry_id = parseInt(url[4].path, 10);

      this.common.getCommonInfo(this.house_id).subscribe(
        p => { this.house_info = p; }
      );

      this.api.getDefectListList(this.house_id).subscribe(
        p => { this.defect = p.filter(dfc => dfc.id === this.defect_id)[0]; }
      );

      this.common.getTepStatuses(this.house_id).subscribe(
        q => { this.statuses = q; }
      );

      this.apiFiles.getFileList(this.house_id).subscribe(
        p => {
          p.filter(img => img.isImage == true)
          .forEach(img => {
            let data = { image:'', thumbImage:'' }
            data.image = 'data:image/jpeg;base64,' + img.raw;
            data.thumbImage = 'data:image/jpeg;base64,' + img.raw;
            this.imageObject.push(data)
        })
        }
      );

      this.api.getDefectList(this.house_id, this.defect_id).subscribe(
        p => {
          this.current_defect = p;
          this.defectentry = p.filter(dfc => dfc.id === this.defect_entry_id)[0];

          this.newForm = this.formBuilder.group({
            id: [this.defectentry.id],
            structural_element_name: [this.defectentry.structural_element_name],
            structural_element_id: [this.defectentry.structural_element_id],
            techStateDescr: [this.defectentry.techStateDescr],
            necessary_work_list: [this.defectentry.necessary_work_list],
            necessary_work_cost: [this.defectentry.necessary_work_cost],
            coefficient: [this.defectentry.coefficient, Validators.required],
            damage: [this.defectentry.damage, Validators.required],
            repair_date_remark: [this.defectentry.repair_date_remark],
            inspection_date_remark: [this.defectentry.inspection_date_remark],
            comment: [this.defectentry.comment, Validators.required],
            structural_element_detail_ids: [this.defectentry.structural_element_detail_ids, Validators.required],
            section: this.formBuilder.array([])
          });

          this.defectref$ = this.api.getDefectRef(this.defectentry.structural_element_id);
        }
      );
    });
  }

  removeSection(index) {
    const result = [];
    const entry_to_remove = this.defectentry.section[index];

    let count = 0;

    this.defectentry.section.forEach(element => {
      if (count !== index) {
        const newsect = <DefectListEntryDetail>{};
        newsect.element_size = element.element_size - entry_to_remove.section_size;
        newsect.section_number = element.section_number > index ? element.section_number - 1 : element.section_number;
        newsect.damage = element.damage;
        newsect.section_size = element.section_size;

        if (element.element_size !== 0 && element.damage !== 0) {
          newsect.damage_by_size = element.damage * (element.section_size / newsect.element_size);
        }
        result.push(newsect);
      }
      count++;
    });

    this.defectentry.section = result;
  }

  addSection() {
    const control = <FormArray>this.newForm.controls.section;

    const newsection = <DefectListEntryDetail>{};

    if (this.defectentry.section.length !== 0) {
      const entries = this.defectentry.section.sort((p, q) => p.section_number - q.section_number
      );
      newsection.section_number = entries[entries.length - 1].section_number + 1;
    } else {
      newsection.section_number = 1;
    }

    newsection.element_size = 0;
    newsection.damage = 0;
    newsection.damage_by_size = 0;
    newsection.section_size = 0;

    const gr = this.formBuilder.group({
      id: ['-1'],
      section_number: [newsection.section_number],
      section_size: [newsection.section_size],
      damage: [newsection.damage],
      element_size: [newsection.element_size],
      damage_by_size: [newsection.damage_by_size]
    });

    gr.controls['section_size'].valueChanges
      .subscribe(p => this.elementSizeListener(p, newsection.section_number));

    gr.controls['damage'].valueChanges
      .subscribe(p => this.damageListener(p, newsection.section_number));

    control.push(gr);
    this.defectentry.section.push(newsection);
  }

  damageListener(val: any, s_number: number) {
    this.defectentry.section[s_number - 1].damage = val;

    this.defectentry.section.forEach(element => {

      const f: FormArray = <FormArray>this.newForm.controls['section'];
      const g: FormGroup = <FormGroup>f.controls[element.section_number - 1];

      if (g.get('section_size').value > 0 && g.get('damage').value > 0) {
        element.damage_by_size =
          (g.get('section_size').value / g.get('element_size').value) * g.get('damage').value;
      } else {
        element.damage_by_size = 0;
      }

      g.setControl('damage_by_size',
        new FormControl({ value: element.damage_by_size, disabled: true }));
    });
  }

  elementSizeListener(val: any, s_number: number) {
    this.defectentry.section[s_number - 1].section_size = val;
    const newsize = this.defectentry.section.map(p => p.section_size).reduce((prev, next) => prev + next);

    this.defectentry.section.forEach(element => {
      element.element_size = newsize;
      const f: FormArray = <FormArray>this.newForm.controls['section'];
      const g: FormGroup = <FormGroup>f.controls[element.section_number - 1];
      g.setControl('element_size', new FormControl(newsize));

      if (g.get('section_size').value > 0 && g.get('damage').value) {
        element.damage_by_size = (g.get('section_size').value /
          g.get('element_size').value) * g.get('damage').value;
      } else {
        element.damage_by_size = 0;
      }

      g.setControl('damage_by_size',
        new FormControl({ value: element.damage_by_size, disabled: true }));
    });
  }


  setStatus(status_id: number, status_name: string) {
    this.common.sendTepStatus(this.house_id, status_id)
      .pipe(first())
      .subscribe(
        data => {
          this.house_info.current_status.status_id = status_id;
          this.house_info.current_status.status_name = status_name;

          this.common.getTepStatuses(this.house_id).subscribe(
            q => { this.statuses = q; }
          );
        },
        error => {
          console.log(error);
        });
  }

  OnChange($event) {
    this.settings.setEditMode($event.srcElement.checked);
  }

  navigateto(structural_element_id) {
    const nav_id = this.current_defect.find(p => p.structural_element_id === structural_element_id).id;
    this.router.navigate(['mkd', this.house_id, 'techstate', this.defect_id, nav_id]);
  }

  onSubmit(form) {
    const result = {};
    result['data'] = form;
    console.log(JSON.stringify(result));

  }
}
