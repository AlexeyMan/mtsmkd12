import {async, ComponentFixture, TestBed} from '@angular/core/testing';

import {TechstatelistComponent} from './techstatelist.component';

describe('TechstatelistComponent', () => {
  let component: TechstatelistComponent;
  let fixture: ComponentFixture<TechstatelistComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ TechstatelistComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TechstatelistComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
