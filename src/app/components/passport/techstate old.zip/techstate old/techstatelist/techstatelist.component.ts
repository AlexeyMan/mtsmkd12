import {Component, OnInit} from '@angular/core';
import {TepMenuItem} from '../../../../_models/tepmenu';
import {TepField} from '../../../../_models/tep';
import {GeneralSettings, HouseInfo} from '../../../../_models/common';
import {Observable} from 'rxjs';
import {CommonService} from '../../../../_services/common.service';
import {ActivatedRoute, Router} from '@angular/router';
import {SettingsService} from '../../../../_services/settings.service';
import {first} from 'rxjs/operators';
import {DefectList} from '../../../../_models/defectlist';
import {TechstateService} from '../../../../_services/techstate.service';
import {Statuses} from '../../../../_models/filters';
import {DocumentsService} from '../../../../_services/documents.service';

@Component({
  selector: 'app-techstatelist',
  templateUrl: './techstatelist.component.html',
  styleUrls: ['./techstatelist.component.scss']
})
export class TechstatelistComponent implements OnInit {

  tepMenu: TepMenuItem[];
  tepFields: TepField[] = [];
  statuses: Statuses[] = [];

  house_id: number;
  tep_part: string;
  menuTitle: string;

  house_info: HouseInfo;

  settings$: Observable<GeneralSettings>;

  defectLists: DefectList[] = [];

  imageObject: Array<object> = [];

  constructor(
    private common: CommonService,
    private route: ActivatedRoute,
    private router: Router,
    private settings: SettingsService,
    private apiFiles: DocumentsService,
    private api: TechstateService
  ) { }

  ngOnInit() {
    this.tepMenu = this.route.snapshot.data['tepMenu'];
    this.tepFields = this.route.snapshot.data['fields'];

    this.tep_part = this.route.snapshot.data['section'];
    this.house_id = this.route.snapshot.data['houseid'];

    this.settings$ = this.settings.settings$;

    this.route.url.subscribe(url => {

      this.house_id = parseFloat(url[1].path);
      this.tep_part = url[2].path;

      this.common.getCommonInfo(this.house_id).subscribe(
        p => { this.house_info = p; }
      );

      this.common.getTepStatuses(this.house_id).subscribe(
        q => { this.statuses = q; }
      );

      this.api.getDefectListList(this.house_id).subscribe(
        p => { this.defectLists = p; }
      );

      this.apiFiles.getFileList(this.house_id).subscribe(
        p => {
          p.filter(img => img.isImage == true)
          .forEach(img => {
            let data = { image:'', thumbImage:'' }
            data.image = 'data:image/jpeg;base64,' + img.raw;
            data.thumbImage = 'data:image/jpeg;base64,' + img.raw;
            this.imageObject.push(data)
        })
        }
      );
    });
  }

  setStatus(status_id: number, status_name: string) {
    this.common.sendTepStatus(this.house_id, status_id)
      .pipe(first())
      .subscribe(
        data => {
          this.house_info.current_status.status_id = status_id;
          this.house_info.current_status.status_name = status_name;

          this.common.getTepStatuses(this.house_id).subscribe(
            q => { this.statuses = q; }
          );
        },
        error => {
          console.log(error);
        });
  }

  OnChange($event) {
    this.settings.setEditMode($event.srcElement.checked);
  }

  onRowClicked(defect_id) {
    this.router.navigate(['mkd', this.house_id, 'techstate', defect_id]);
  }
}
